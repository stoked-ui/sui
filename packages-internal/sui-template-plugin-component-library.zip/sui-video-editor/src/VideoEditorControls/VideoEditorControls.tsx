import * as React from 'react';
import { FileBase } from '@stoked-ui/file-explorer';
import { useSlotProps } from '@mui/base/utils';
import { styled, createUseThemeProps } from '../internals/zero-styled';
import { VideoEditorControlsProps } from './VideoEditorControls.types';
import composeClasses from "@mui/utils/composeClasses";
import { getVideoEditorControlsUtilityClass } from "./videoEditorControlsClasses";

const useThemeProps = createUseThemeProps('MuiVideoEditorControls');

const useUtilityClasses = <R extends FileBase, Multiple extends boolean | undefined>(
  ownerState: VideoEditorControlsProps<R, Multiple>,
) => {
  const { classes } = ownerState;

  const slots = {
    root: ['root'],
  };

  return composeClasses(slots, getVideoEditorControlsUtilityClass, classes);
};

const VideoEditorControlsRoot = styled('div')(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  width: '100%',
  '& .player-panel': {
    width: '100%',
    height: '500px',
    position: 'relative',

    '& .lottie-ani': {
      position: 'absolute',
      width: '100%',
      height: '100%',
      left: 0,
      top: 0,
    }
  },
  overflow: 'hidden',
}));

/**
 *
 * Demos:
 *
 * - [FileExplorer View](https://stoked-ui.github.io/video-editor/docs/)
 *
 * API:
 *
 * - [FileExplorer API](https://stoked-ui.github.io/video-editor/api/)
 */
export const VideoEditorControls = React.forwardRef(function VideoEditorControls<
  R extends FileBase = FileBase,
  Multiple extends boolean | undefined = undefined,
>(inProps: VideoEditorControlsProps<R, Multiple>, ref: React.Ref<HTMLDivElement>): React.JSX.Element {
  const props = useThemeProps({ props: inProps, name: 'MuiVideoEditorControls' });

  const { slots, slotProps } = props;
  const classes = useUtilityClasses(props);

  const Root = slots?.root ?? VideoEditorControlsRoot;
  const rootProps = useSlotProps({
    elementType: Root,
    externalSlotProps: slotProps?.root,
    className: classes.root,
    ownerState: props,
  });

  return (
      <div>derp</div>
  )
})

