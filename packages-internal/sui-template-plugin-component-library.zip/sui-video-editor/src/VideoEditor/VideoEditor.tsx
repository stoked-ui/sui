import { Timeline } from '@stoked-ui/timeline';
import { FileBase, FileExplorer } from '@stoked-ui/file-explorer';
import { useSlotProps } from '@mui/base/utils';
import * as React from 'react';
import { styled, createUseThemeProps } from '../internals/zero-styled';
import { useVideoEditor } from '../internals/useVideoEditor';
import { VideoEditorProps } from './VideoEditor.types';
import { VideoEditorPluginSignatures, VIDEO_EDITOR_PLUGINS } from './VideoEditor.plugins';
import VideoEditorProvider from "./VideoEditorProvider";
import { VideoEditorControls } from "../VideoEditorControls";
import { ViewSpace } from "../ViewSpace";
import composeClasses from "@mui/utils/composeClasses";
import { getVideoEditorUtilityClass } from "./videoEditorClasses";

const useThemeProps = createUseThemeProps('MuiVideoEditor');

const useUtilityClasses = <R extends FileBase, Multiple extends boolean | undefined>(
  ownerState: VideoEditorProps<R, Multiple>,
) => {
  const { classes } = ownerState;

  const slots = {
    root: ['root'],
    viewSpace: ['viewSpace'],
    videoControls: ['videoControls'],
    timeline: ['timeline'],
    bottomLeft: ['bottomLeft'],
    bottomRight: ['bottomRight'],
  };

  return composeClasses(slots, getVideoEditorUtilityClass, classes);
};

const VideoEditorRoot = styled('div')(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  width: '100%',
  '& .player-panel': {
    width: '100%',
    height: '500px',
    position: 'relative',

    '& .lottie-ani': {
      position: 'absolute',
      width: '100%',
      height: '100%',
      left: 0,
      top: 0,
    }
  },
  overflow: 'hidden',
}));

/**
 *
 * Demos:
 *
 * - [FileExplorer View](https://stoked-ui.github.io/video-editor/docs/)
 *
 * API:
 *
 * - [FileExplorer API](https://stoked-ui.github.io/video-editor/api/)
 */
export const VideoEditor = React.forwardRef(function VideoEditor<
  R extends FileBase = FileBase,
  Multiple extends boolean | undefined = undefined,
>(inProps: VideoEditorProps<R, Multiple>, ref: React.Ref<HTMLDivElement>): React.JSX.Element {
  const props = useThemeProps({ props: inProps, name: 'MuiVideoEditor' });

  const {
    getRootProps,
    getViewSpaceProps,
    getControlsProps,
    getTimelineProps,
    getBottomLeftProps,
    getBottomRightProps,
    contextValue,
    instance
  } = useVideoEditor<VideoEditorPluginSignatures, typeof props>({
    plugins: VIDEO_EDITOR_PLUGINS,
    rootRef: ref,
    props,
  });

  const { slots, slotProps } = props;
  const classes = useUtilityClasses(props);

  const Root = slots?.root ?? VideoEditorRoot;
  const rootProps = useSlotProps({
    elementType: Root,
    externalSlotProps: slotProps?.root,
    className: classes.root,
    getSlotProps: getRootProps,
    ownerState: props,
  });

  const ViewSpaceSlot = slots?.viewSpace ?? ViewSpace;
  const viewSpaceProps = useSlotProps({
    elementType: ViewSpaceSlot,
    externalSlotProps: slotProps?.viewSpace,
    className: classes.viewSpace,
    getSlotProps: getViewSpaceProps,
    ownerState: props,
  });

  const ControlsSlot = slots?.videoControls ?? VideoEditorControls;
  const videoControlsProps = useSlotProps({
    elementType: ControlsSlot,
    externalSlotProps: slotProps?.videoControls,
    className: classes.videoControls,
    getSlotProps: getControlsProps,
    ownerState: props,
  });

  const TimelineSlot = slots?.timeline ?? Timeline;
  const timelineProps = useSlotProps({
    elementType: TimelineSlot,
    externalSlotProps: slotProps?.timeline,
    className: classes.timeline,
    getSlotProps: getTimelineProps,
    ownerState: props,
  });

  const BottomLeft = slots?.bottomLeft ?? FileExplorer;
  const bottomLeftProps = useSlotProps({
    elementType: BottomLeft,
    externalSlotProps: slotProps?.bottomLeft,
    className: classes.bottomLeft,
    getSlotProps: getBottomLeftProps,
    ownerState: props as any,
  });

  const BottomRight = slots?.bottomRight ?? FileExplorer;
  const bottomRightProps = useSlotProps({
    elementType: BottomRight,
      externalSlotProps: slotProps?.bottomRight,
    className: classes.bottomRight,
    getSlotProps: getBottomRightProps,
    ownerState: props as any,
  });

  const [data, setData] = React.useState();
  const timelineState = React.useRef(null);
  const playerPanel = React.useRef(null);

  return (
    <VideoEditorProvider>
      <div>derp</div>
    </VideoEditorProvider>
  )
})

