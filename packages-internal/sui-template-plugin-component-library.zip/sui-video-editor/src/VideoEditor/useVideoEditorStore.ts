import { IndexedDB } from "react-indexed-db-hook";

export const useVideoEditor = (props: { stores: string[] }) => {

};
