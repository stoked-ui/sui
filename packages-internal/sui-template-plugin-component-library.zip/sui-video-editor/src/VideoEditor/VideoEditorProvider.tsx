import * as React from 'react';
import { IndexedDB, ObjectStoreMeta } from "react-indexed-db-hook";

const fileSchema: ObjectStoreMeta = {
  store: "videos",
  storeConfig: { keyPath: "id", autoIncrement: true },
  storeSchema: [
    { name: "name", keypath: "name", options: { unique: false } },
  ],
}

export default function VideoEditorProvider({children}: {children: React.ReactNode}) {
  return (
    <IndexedDB
      name="stoked-ui-video-editor"
      version={1}
      objectStoresMeta={[
        fileSchema,
      ]}
    >
      {children}
    </IndexedDB>
  );
}
