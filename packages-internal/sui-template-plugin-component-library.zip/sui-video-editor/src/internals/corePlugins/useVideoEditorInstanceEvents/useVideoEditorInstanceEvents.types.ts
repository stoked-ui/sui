import { VideoEditorPluginSignature } from '../../models/plugin';
import { VideoEditorEventListener } from '../../models/events';

export interface UseVideoEditorInstanceEventsInstance {
  /**
   * Should never be used directly.
   * Please use `useInstanceEventHandler` instead.
   * @param {string} eventName Name of the event to subscribe to.
   * @param {VideoEditorEventListener<any>} handler Event handler to call when the event is published.
   * @returns {() => void} Cleanup function.
   */
  $$subscribeEvent: (eventName: string, handler: VideoEditorEventListener<any>) => () => void;
  /**
   * Should never be used directly.
   * Please use `publishVideoEditorEvent` instead.
   * @param {string} eventName Name of the event to publish.
   * @param {any} params The params to publish with the event.
   */
  $$publishEvent: (eventName: string, params: any) => void;
}

export type UseVideoEditorInstanceEventsSignature = VideoEditorPluginSignature<{
  instance: UseVideoEditorInstanceEventsInstance;
}>;
