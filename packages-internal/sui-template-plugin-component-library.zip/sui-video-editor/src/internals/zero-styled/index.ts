import { useThemeProps } from '@mui/material/styles';

export { styled } from '@mui/material/styles';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function createUseThemeProps(name: string) {
  return useThemeProps;
}
