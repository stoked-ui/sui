export { useVideoEditorSelection } from './useVideoEditorSelection';
export type {
  UseVideoEditorSelectionSignature,
  UseVideoEditorSelectionParameters,
  UseVideoEditorSelectionDefaultizedParameters,
} from './useVideoEditorSelection.types';
